﻿namespace WF.FormInventory.CLI
{
    internal interface ICsvUtilities
    {
        void CreateFormElementsCsvText(FormBuilderRoot[] allFormsArray);
        void CreateFormSectionElementsCsvText(FormBuilderRoot[] allFormsArray);
        void CreateRawFormElementsCsvText(FormBuilderRoot[] allFormsArray);
        void CreateFormsCsvText(FormBuilderRoot[] allFormsArray);
        void CreateServiceRequestItemsCsvText(FormBuilderRoot[] allFormsArray);
    }
}
