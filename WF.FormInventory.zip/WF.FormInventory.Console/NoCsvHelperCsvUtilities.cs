﻿using System;

namespace WF.FormInventory.CLI
{
    //internal class NoCsvHelperCsvUtilities : ICsvUtilities
    //{
    //    public void CreateFormElementsCsvText(FormBuilderRoot[] allFormsArray)
    //    {
    //        Console.WriteLine("Generating form elements CSV data");
    //    }
    //    public void CreateRawFormElementsCsvText(FormBuilderRoot[] allFormsArray)
    //    {
    //        Console.WriteLine("Generating raw form elements CSV data");
    //    }

    //    public void CreateFormsCsvText(FormBuilderRoot[] allFormsArray)
    //    {
    //        Console.WriteLine("Generating forms CSV data");
    //    }

    //    public void CreateServiceRequestItemsCsvText(FormBuilderRoot[] allFormsArray)
    //    {
    //        Console.WriteLine("Generating service requiest items CSV data");
    //    }
    //}
}
