﻿using CsvHelper;
using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace WF.FormInventory.CLI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Extracting data from {Constants.FBX_DIR}...");
            List<FormBuilderRoot> allForms = new List<FormBuilderRoot>();

            foreach (string file in Directory.EnumerateFiles(Constants.FBX_DIR, $"*.{Constants.FBX_FILE_EXTENSION}", SearchOption.AllDirectories))
            {
                using (FileStream fileStream = new FileStream(file, FileMode.Open, FileAccess.Read))
                {
                    using (ZipArchive archive = new ZipArchive(fileStream, ZipArchiveMode.Read))
                    {
                        ZipArchiveEntry jsonDataFile = archive.Entries.Single(e => e.FullName.Equals(Constants.JSON_DATA_FILENAME));
                        FormBuilderRoot form;
                        using (var stream = jsonDataFile.Open())
                        using (var reader = new StreamReader(stream))
                        {
                            form = JsonSerializer.Deserialize<FormBuilderRoot>(reader.ReadToEnd());
                            allForms.Add(form);
                        }
                        if (form == null)
                            Console.WriteLine("Could not read form data...");
                        else
                            Console.WriteLine($"Found for {form.Form.Name} using platform {form.Form.PlatformId} in file {jsonDataFile.FullName}");
                    }
                }
            }

            var allFormsArray = allForms.ToArray();

            ICsvUtilities csvUtilities = new CsvHelperCsvUtilities();
            csvUtilities.CreateFormsCsvText(allFormsArray);
            csvUtilities.CreateFormSectionElementsCsvText(allFormsArray);
            csvUtilities.CreateFormElementsCsvText(allFormsArray);
            csvUtilities.CreateRawFormElementsCsvText(allFormsArray);
            //csvUtilities.CreateServiceRequestItemsCsvText(allFormsArray);

            Console.WriteLine("Done");
            Console.Read();
        }
    }

    internal static class Extensions
    {
        public static CsvFormElement MapToCsvFormElement(this FormElement formElement, IEnumerable<Form> allForms)
        {
            string fieldLabel = formElement.Configurations.FirstOrDefault(c => c.FormElementConfigurationName.Equals(Constants.FormElementsConfigurations.FIELD_LABEL))?.Value
                ?? formElement.Configurations.FirstOrDefault(c => c.FormElementConfigurationName.Equals(Constants.FormElementsConfigurations.HEADER_TEXT))?.Value;

            Form parentForm = allForms.FirstOrDefault(f => f.FormGuid.Equals(formElement.FormGuid));

            return new CsvFormElement
            {
                InputType = formElement.InputTypeName,
                FormID = formElement.FormGuid,
                FormName = parentForm.Name,
                FormPlatformId = parentForm.PlatformId,
                FormTypeId = parentForm.FormTypeId,
                FormElementID = formElement.FormElementGuid,
                InputName = formElement.DisplayText,
                FieldLabel = fieldLabel
            };
        }

        public static IEnumerable<T> SelectRecursively<T>(this T source, Func<T, IEnumerable<T>> selector)
        {
            return selector(source).SelectMany(x => x.SelectRecursively(selector).Prepend(x));
        }
    }

    public class CsvFormElement
    {
        public string InputType { get; internal set; }
        public string InputName { get; internal set; }
        public string FieldLabel { get; internal set; }
        public string FormID { get; internal set; }
        public string FormElementID { get; internal set; }
        public string FormName { get; internal set; }
        public int FormPlatformId { get; internal set; }
        public int FormTypeId { get; internal set; }
    }

    internal class CsvHelperCsvUtilities : ICsvUtilities
    {
        public void CreateFormElementsCsvText(FormBuilderRoot[] formJson)
        {
            Console.WriteLine("Generating form elements CSV data");
            using (var writer = new StreamWriter(Constants.FORM_ELEMENTS_CSV_FILEPATH))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                //create filter condition
                Func<FormElement, bool> formElementFilter =
                    fe => !fe.InputTypeName.Equals(Constants.InputTypes.SRI_ATTRIBUTE)
                        && !fe.InputTypeName.Equals(Constants.InputTypes.VALIDATOR)
                        && !fe.InputTypeName.Equals(Constants.InputTypes.LIST_ITEM)
                        && !fe.InputTypeName.Equals(Constants.InputTypes.LABEL);

                csv.Context.RegisterClassMap<FormElementMap>();
                var filteredFormElements = GetAllFormElements(formJson)
                    .Where(formElementFilter) //filter out the elements we don't want
                    .Select(fe => fe.MapToCsvFormElement(formJson.Select(root => root.Form))); //map
                csv.WriteRecords(filteredFormElements);
            }
        }
        public void CreateFormSectionElementsCsvText(FormBuilderRoot[] formJson)
        {
            Console.WriteLine("Generating raw form elements CSV data");
            using (var writer = new StreamWriter(Constants.FORM_SECTION_ELEMENTS_CSV_FILEPATH))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                //create filter condition
                Func<FormElement, bool> formElementFilter =
                    fe => fe.InputTypeName.Equals(Constants.InputTypes.SECTION);

                //get top level section elements only
                csv.Context.RegisterClassMap<FormElementMap>();
                var allFormElements = formJson
                    .SelectMany(f => f.Form.FormElements.OrderBy(e => e.DisplayPosition)) //first level of form elements ONLY selected here
                    .Where(formElementFilter) //filter out the elements we don't want
                    .Select(fe => fe.MapToCsvFormElement(formJson.Select(root => root.Form))); //map
                csv.WriteRecords(allFormElements);
            }
        }
        public void CreateRawFormElementsCsvText(FormBuilderRoot[] formJson)
        {
            Console.WriteLine("Generating raw form elements CSV data");
            using (var writer = new StreamWriter(Constants.RAW_FORM_ELEMENTS_CSV_FILEPATH))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.Context.RegisterClassMap<FormElementMap>();
                var allFormElements = GetAllFormElements(formJson)
                    .Select(fe => fe.MapToCsvFormElement(formJson.Select(root => root.Form))); //map
                csv.WriteRecords(allFormElements);
            }
        }

        private static IEnumerable<FormElement> GetAllFormElements(FormBuilderRoot[] formJson)
        {
            return formJson.SelectMany(f => f.Form.FormElements.OrderBy(e => e.DisplayPosition).SelectMany(fe => fe.SelectRecursively(elem => elem.ChildElements.OrderBy(e => e.DisplayPosition)).Prepend(fe))); //recurse through the hierarchy of child elements;
        }

        public void CreateServiceRequestItemsCsvText(FormBuilderRoot[] formJson)
        {
            Console.WriteLine("Generating service requiest items CSV data");
            using (var writer = new StreamWriter(Constants.SERVICE_REQUESTS_CSV_FILEPATH))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.Context.RegisterClassMap<ServiceRequestItemMap>();
                csv.WriteRecords(formJson.SelectMany(f => f.Form.ServiceRequestItems));
            }
        }
        public void CreateFormsCsvText(FormBuilderRoot[] formJson)
        {
            Console.WriteLine("Generating forms CSV data");
            using (var writer = new StreamWriter(Constants.FORMS_CSV_FILEPATH))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.Context.RegisterClassMap<FormMap>();
                csv.WriteRecords(formJson.Select(f => f.Form));
            }
        }
    }

    public class FormElementMap : ClassMap<CsvFormElement>
    {
        public FormElementMap()
        {
            Map(m => m.FormID).Index(0).Name("Form ID");
            Map(m => m.FormName).Index(0).Name("Form Name");
            Map(m => m.FormTypeId).Index(0).Name("Form Type ID");
            Map(m => m.FormPlatformId).Index(0).Name("Form Platform ID");
            Map(m => m.InputType).Index(1).Name("Input Type");
            Map(m => m.InputName).Index(2).Name("FB Input Name");
            Map(m => m.FieldLabel).Index(3).Name("Field Label");
            Map(m => m.FormElementID).Index(4).Name("Form Element ID");
        }
    }

    public class ServiceRequestItemMap : ClassMap<ServiceRequestItem>
    {
        public ServiceRequestItemMap()
        {
            Map(m => m.ServiceRequestItemGuid).Index(0).Name("ID");
            Map(m => m.DisplayText).Index(1).Name("Type ID");
            Map(m => m.FormGuid).Index(2).Name("Form ID");
        }
    }

    public class FormMap : ClassMap<Form>
    {
        public FormMap()
        {
            Map(m => m.FormGuid).Index(0).Name("ID");
            Map(m => m.Name).Index(1).Name("Name");
            Map(m => m.FormTypeId).Index(2).Name("Form Type Id");
            Map(m => m.PlatformId).Index(3).Name("Platform Id");
        }
    }
}
