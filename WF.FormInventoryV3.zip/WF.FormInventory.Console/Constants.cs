﻿namespace WF.FormInventory.CLI
{
    public static class Constants 
    {
        public const string FBX_DIR = @"TODO: insert your FBX directory path here";
        public const string FBX_FILE_EXTENSION = "fbx";
        public const string JSON_DATA_FILENAME = "Form.xml";
        public const string FORMS_CSV_FILEPATH = "formsInventory.csv";
        public const string FORM_ELEMENTS_CSV_FILEPATH = "formElementsInventory.csv";
        public const string FORM_SECTION_ELEMENTS_CSV_FILEPATH = "formSectionElementsInventory.csv";
        public const string RAW_FORM_ELEMENTS_CSV_FILEPATH = "rawFormElementsInventory.csv";
        public const string BUSINESS_RULE_CODES_CSV_FILEPATH = "businessRuleCodesInventory.csv";
        public const string RSI_ATTRIBUTES_CSV_FILEPATH = "rsiAttributesInventory.csv";

        public static class InputTypes
        {
            public const string SRI_ATTRIBUTE = "SRI Attribute";
            public const string VALIDATOR = "Validator";
            public const string LIST_ITEM = "List Item";
            public const string LABEL = "Label";
            public const string SECTION = "Section";
        }

        public static class FormElementsConfigurations
        {
            public const string FIELD_LABEL = "Field Label";
            public const string HEADER_TEXT = "Header Text";
        }
    }
}
